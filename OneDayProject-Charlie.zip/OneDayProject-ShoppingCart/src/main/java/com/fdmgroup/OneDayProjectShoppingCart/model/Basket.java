package com.fdmgroup.OneDayProjectShoppingCart.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.SequenceGenerator;

@Entity
public class Basket {
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "basket_gen")
	@SequenceGenerator(name = "basket_gen", sequenceName = "BASKET_SEQ", allocationSize = 1)
	private long basketId;
	
	@ManyToMany(cascade = CascadeType.MERGE)
	@JoinColumn(name="albumId")
	private List<Album> albums;
	
	public Basket() {
		super();
	}


	public long getBasketId() {
		return basketId;
	}


	public void setBasketId(long basketId) {
		this.basketId = basketId;
	}


	public List<Album> getAlbums() {
		return albums;
	}


	public void setAlbums(List<Album> albums) {
		this.albums = albums;
	}

}
