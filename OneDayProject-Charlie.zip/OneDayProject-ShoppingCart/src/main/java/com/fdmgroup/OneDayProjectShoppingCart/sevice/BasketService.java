package com.fdmgroup.OneDayProjectShoppingCart.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdmgroup.OneDayProjectShoppingCart.model.Album;
import com.fdmgroup.OneDayProjectShoppingCart.model.Basket;
import com.fdmgroup.OneDayProjectShoppingCart.repository.BasketDao;

@Service
public class BasketService {

	@Autowired
	private BasketDao basketDao;

	public void create(Basket basket) {
		basketDao.save(basket);
	}

	public Basket retrieveOne(long id) {
		return basketDao.getOne(id);
	}

	public void add(Basket basket, Album album) {
		List<Album> albums = basket.getAlbums();
		albums.add(album);
		basket.setAlbums(albums);
		basketDao.save(basket);
	}

}
