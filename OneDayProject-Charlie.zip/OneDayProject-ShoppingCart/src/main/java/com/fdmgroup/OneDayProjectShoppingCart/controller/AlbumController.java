package com.fdmgroup.OneDayProjectShoppingCart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fdmgroup.OneDayProjectShoppingCart.model.Account;
import com.fdmgroup.OneDayProjectShoppingCart.model.Album;
import com.fdmgroup.OneDayProjectShoppingCart.model.Basket;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AccountService;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AlbumService;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.BasketService;

@Controller
public class AlbumController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	AlbumService albumService;
	
	@Autowired
	BasketService basketService;
	
	@GetMapping("/AllAlbums/{accountId}")
	public ModelAndView homePage(@PathVariable("accountId") Long accountId, Account account, ModelAndView modelAndView) {
		account = accountService.retrieveOne(accountId);
		modelAndView.addObject("basket", account.getBasket());
		modelAndView.addObject("account", account);
		modelAndView.addObject("allAlbums", albumService.retrieveAll());
		modelAndView.setViewName("/allAlbums.jsp");
		return modelAndView;
	}
	
	@PostMapping("/AddToBasket/{accountId}/{basketId}/{albumId}")
	public ModelAndView addToBasket(@ModelAttribute("quantity") int qty, @PathVariable("albumId") Long albumId, @PathVariable("basketId") Long basketId, @PathVariable("accountId") Long accountId, ModelMap model) {
		Album album = albumService.retrieveOne(albumId);
		Basket basket = basketService.retrieveOne(basketId);
		Account account = accountService.retrieveOne(accountId);
		if (qty > album.getStock()) {
			model.addAttribute("message", "Not enough copies in stock to fill this order");
		} else {
			if (qty > 1) {
				for (int count = 0 ; count < qty ; count++) {
					basketService.add(basket, album);					
				}
				model.addAttribute("message", qty + " copies of " + album.getTitle() + " by " + album.getArtist() + " has beeen added to your basket");
			} else {
				basketService.add(basket, album);
				model.addAttribute("message", album.getTitle() + " by " + album.getArtist() + " has beeen added to your basket");
			}
			album.setStock(album.getStock() - qty);
			albumService.update(album);
		}
		
		model.addAttribute("basket", basket);
		model.addAttribute("account", account);
		
		return new ModelAndView("/allAlbums.jsp", "allAlbums", albumService.retrieveAll());
	}

}
