package com.fdmgroup.OneDayProjectShoppingCart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fdmgroup.OneDayProjectShoppingCart.model.Album;


public interface AlbumDao extends JpaRepository<Album, Long> {

}
