package com.fdmgroup.OneDayProjectShoppingCart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fdmgroup.OneDayProjectShoppingCart.model.Basket;

public interface BasketDao extends JpaRepository<Basket, Long> {

}
