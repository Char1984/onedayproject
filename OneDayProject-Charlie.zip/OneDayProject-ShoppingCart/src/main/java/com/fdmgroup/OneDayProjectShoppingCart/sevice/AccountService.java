package com.fdmgroup.OneDayProjectShoppingCart.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdmgroup.OneDayProjectShoppingCart.model.Account;
import com.fdmgroup.OneDayProjectShoppingCart.model.Basket;
import com.fdmgroup.OneDayProjectShoppingCart.repository.AccountDao;

@Service
public class AccountService {
	
	@Autowired
	private AccountDao accountDao;
	
	@Autowired
	private BasketService basketService;

	public void create(Account account) {
		Basket basket = new Basket();
		basketService.create(basket);
		account.setBasket(basket);
		accountDao.save(account);		
	}
	
	public Account retrieveOne(long Id) {
		Account account = accountDao.getOne(Id);
		return account;
	}

	public List<Account> retrieveAll() {
		return accountDao.findAll();
	}

	
	
	

}
