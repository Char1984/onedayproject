package com.fdmgroup.OneDayProjectShoppingCart.sevice;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fdmgroup.OneDayProjectShoppingCart.model.Album;
import com.fdmgroup.OneDayProjectShoppingCart.repository.AlbumDao;

@Service
public class AlbumService {
	
	@Autowired
	private AlbumDao albumDao;
	
	public void create(Album album) {
		albumDao.save(album);
	}

	public Album retrieveOne(long id) {
		return albumDao.getOne(id);
	}

	public List<Album> retrieveAll() {
		return albumDao.findAll();
	}

	public void update(Album album) {
		albumDao.save(album);
	}

	

}
