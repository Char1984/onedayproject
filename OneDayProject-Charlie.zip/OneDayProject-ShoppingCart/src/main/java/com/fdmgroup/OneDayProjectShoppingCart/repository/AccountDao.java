package com.fdmgroup.OneDayProjectShoppingCart.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.fdmgroup.OneDayProjectShoppingCart.model.Account;

public interface AccountDao extends JpaRepository<Account, Long> {

}
