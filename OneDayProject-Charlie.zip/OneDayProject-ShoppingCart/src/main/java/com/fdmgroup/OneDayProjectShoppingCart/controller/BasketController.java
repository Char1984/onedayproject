package com.fdmgroup.OneDayProjectShoppingCart.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.servlet.ModelAndView;

import com.fdmgroup.OneDayProjectShoppingCart.model.Account;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AccountService;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.BasketService;

@Controller
public class BasketController {
	
	@Autowired
	AccountService accountService;
	
	@Autowired
	BasketService basketService;
	
	@GetMapping("Basket/{accountId}")
	public ModelAndView homePage(@PathVariable("accountId") Long accountId, Account account, ModelAndView modelAndView) {
		account = accountService.retrieveOne(accountId);
		modelAndView.addObject("name", account.getName());
		modelAndView.addObject("accountId", accountId);
		modelAndView.addObject("albums", basketService.retrieveOne(1).getAlbums());
		modelAndView.setViewName("/basket.jsp");
		return modelAndView;
	}

}
