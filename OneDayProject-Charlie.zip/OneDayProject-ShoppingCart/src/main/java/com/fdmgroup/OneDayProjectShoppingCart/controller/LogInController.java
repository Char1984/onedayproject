package com.fdmgroup.OneDayProjectShoppingCart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.fdmgroup.OneDayProjectShoppingCart.model.Account;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AccountService;

@Controller
public class LogInController {

	@Autowired
	private AccountService accountService;

	@GetMapping("/Login")
	public String login() {
		return "login.jsp";
	}

	@PostMapping("/LoginSubmit")
	public ModelAndView loginSubmit(@ModelAttribute("name") String name, ModelAndView modelAndView) {
		List<Account> accounts = accountService.retrieveAll();
		for (Account account : accounts) {
			if (account.getName().equals(name)) {
				modelAndView.addObject("account", account);
				modelAndView.setViewName("user.jsp");
				return modelAndView;
			}			
		}
		modelAndView.addObject("message", "Name is not in the database. Please create an account");
		modelAndView.setViewName("login.jsp");
		return modelAndView;
	}
	
	@PostMapping("/NewAccount")
	public ModelAndView newAccount(@ModelAttribute("name") String name, Account account, ModelAndView modelAndView) {
		account = new Account(name);
		accountService.create(account);
		modelAndView.addObject("account", account);
		modelAndView.setViewName("user.jsp");
		return modelAndView;
	}
}
