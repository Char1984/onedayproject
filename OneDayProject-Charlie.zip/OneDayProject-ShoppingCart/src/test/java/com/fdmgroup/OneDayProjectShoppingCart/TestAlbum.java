package com.fdmgroup.OneDayProjectShoppingCart;

import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.fdmgroup.OneDayProjectShoppingCart.model.Album;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AlbumService;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
class TestAlbum {
	
	@Autowired
	private AlbumService albumService;

	@Test
	void test_AnAlbumCanBeCreated() {
		Album album = new Album("Surfer Rosa", "Pixies", "4AD", 1988, 21.99, 1);
		albumService.create(album);
		assertTrue(album.getAlbumId()>0);
	}
	@Test
	void test_CanRetrieveAnAlbumFromTheDatabase() {
		Album album = albumService.retrieveOne(1);
		assertEquals("Sgt Peppers Lonely Hearts Club Band", album.getTitle());
	}
	
	@Test
	void test_CanRetrieveAllAlbumsFromTheDatabase() {
		List<Album> albums = albumService.retrieveAll();
		assertEquals(7, albums.size());
	}
	
	@Test
	void test_AnAlbumCanBeUpdated() {
		Album albumBeforeUpdate = albumService.retrieveOne(1);
		int quantityInStockBeforeUpdating = albumBeforeUpdate.getStock();
		albumBeforeUpdate.setStock(quantityInStockBeforeUpdating-3);
		albumService.update(albumBeforeUpdate);
		Album albumAfterUpdate = albumService.retrieveOne(1);
		int quantityInStockAfterUpdating = albumAfterUpdate.getStock();
		assertEquals(quantityInStockAfterUpdating+3, quantityInStockAfterUpdating);
	}
	

}
