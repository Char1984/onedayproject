package com.fdmgroup.OneDayProjectShoppingCart;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.fdmgroup.OneDayProjectShoppingCart.model.Account;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AccountService;


@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
class TestAccount {

	@Autowired
	AccountService accountService;
	
	@Test
	void test_AnAccountCanBecreated() {
		Account account = new Account("Joe");
		accountService.create(account);
		assertTrue(account.getAccountId()>0);
	}
	
	@Test
	void test_AnAccountCanBeRetrievedFromTheDatabase() {
		Account account = accountService.retrieveOne(1);
		assertEquals("Charlie", account.getName());
	}
	
	@Test
	void test_CanRetrieveAListOfAllAccounts() {
		List<Account> accounts = accountService.retrieveAll();
		assertEquals(1, accounts.size());
	}

}
