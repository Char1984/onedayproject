package com.fdmgroup.OneDayProjectShoppingCart;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.DirtiesContext;

import com.fdmgroup.OneDayProjectShoppingCart.model.Album;
import com.fdmgroup.OneDayProjectShoppingCart.model.Basket;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.AlbumService;
import com.fdmgroup.OneDayProjectShoppingCart.sevice.BasketService;

@SpringBootTest
@DirtiesContext(classMode = DirtiesContext.ClassMode.BEFORE_EACH_TEST_METHOD)
class TestBasket {
	
	@Autowired
	private BasketService basketService;
	
	@Autowired
	private AlbumService albumService;
	
	@Test
	void test_CanCreateABasket() {
		Basket basket = new Basket();
		basketService.create(basket);
		assertTrue(basket.getBasketId()>0);
	}
	
	@Test
	void test_ABasketCanBeRetrieved() {
		Basket basket = basketService.retrieveOne(1);
		String title = basket.getAlbums().get(0).getTitle();
		assertEquals("Sgt Peppers Lonely Hearts Club Band", title);
	}
	
	@Test
	void test_AnAlbumCanBeAddedToTheBasket() {
		Album album = albumService.retrieveOne(1);
		Basket basket = basketService.retrieveOne(1);
		int numberOfItemsInBasket = basket.getAlbums().size();
		basketService.add(basket, album);
		assertEquals(numberOfItemsInBasket, basket.getAlbums().size());
		
	}
	

}
